#!/bin/bash
cp ../turndb/schema.sql mysql/
cp ../turndb/schema.sql postgresql/
